<?php
$folder = '/Users/lucbu/Downloads/XAMP/htdocs/ASE-230/Delicous-Master/delicious-master';
if (isset($_GET['file'])) {
    $filename = $_GET['file'];
    $filepath = $folder . '/' . $filename;
    
    if (file_exists($filepath)) {
        // Load the HTML content
        $content = file_get_contents($filepath);
        
        // Load the associated CSS (if available)
        $cssPath = str_replace('.html', '.css', $filepath);
        $cssContent = '';
        if (file_exists($cssPath)) {
            $cssContent = file_get_contents($cssPath);
        }
        
        echo '<h1>View File: ' . $filename . '</h1>';
        
        // Apply CSS styles
        echo '<style>' . $cssContent . '</style>';
        
        // Display the HTML content
        echo $content;
    } else {
        echo 'File not found.';
    }
} else {
    echo 'Invalid request.';
}
?>
