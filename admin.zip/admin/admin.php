<!DOCTYPE html>
<html>
<head>
    <title>Admin Page</title>
</head>
<body>
    <h1>Admin Page</h1>
</body>
<?php
$folder = '/Users/lucbu/Downloads/XAMP/htdocs/ASE-230/Delicous-Master/delicious-master';

// Get the list of filenames in the folder
$files = scandir($folder);

// Filter out . and .. if they exist
$files = array_diff($files, array('.', '..'));

// Display the filenames in a table
echo '<table border="1">';
echo '<tr><th>Filename</th><th>Actions</th></tr>';
foreach ($files as $filename) {
    echo '<tr>';
    echo '<td>' . $filename . '</td>';
    echo '<td>';
    echo '<a href="view.php?file=' . $filename . '">View</a> ';
    echo '<a href="edit.php?file=' . $filename . '">Edit</a> ';
    echo '<a href="delete.php?file=' . $filename . '">Delete</a>';
    echo '</td>';
    echo '</tr>';
}
echo '</table>';
//create a file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newFileName = $_POST['newFileName'];
    $newFileContent = $_POST['newFileContent'];
    
    // Create a new file in the folder
    $newFilePath = $folder . '/' . $newFileName;
    
    if (file_put_contents($newFilePath, $newFileContent) !== false) {
        echo 'File created successfully.';
    } else {
        echo 'Failed to create the file.';
    }
}

echo '<h1>Admin Panel</h1>';
echo '<form method="post">';
echo '<label for="newFileName">New File Name:</label>';
echo '<input type="text" name="newFileName" required><br>';
echo '<label for="newFileContent">File Content:</label>';
echo '<textarea name="newFileContent" rows="10" cols="50"></textarea><br>';
echo '<input type="submit" value="Create File">';
echo '</form>';
?>
</html>